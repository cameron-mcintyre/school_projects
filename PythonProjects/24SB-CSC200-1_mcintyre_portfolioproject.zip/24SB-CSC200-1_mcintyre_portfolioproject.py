#CSC200-1 Portfolio Project
#Cameron McIntyre 6/1/2024
#File Renaming Program

import os
import re

def main():

    initialfolder = input('Please indicate the folder location with the files you would like to rename: ')

    for file in os.listdir(initialfolder):
        namedateprefix = findfilenamedate(file)

        if namedateprefix is None:
            print('This file had no date in it!')
            continue
        else:
            changefilenames(namedateprefix, initialfolder, file)

def findfilenamedate(file):

    dtginfile = re.search(r'(\d{8})', file)

    if dtginfile:
        dtginfilegrp = dtginfile.group(1)
        filedate = str(dtginfilegrp) + '_'
        print('Date found! It is: ' + filedate)
        return filedate
    else:
        print('No date found, sorry.')
        return None

def changefilenames(namedateprefix, initialfolder, file):
    newfilename = namedateprefix + file
    print(file)
    oldfile = os.path.join(initialfolder, file)
    newfile = os.path.join(initialfolder, newfilename)
    os.rename(oldfile, newfile)
    print(newfilename)

main()
